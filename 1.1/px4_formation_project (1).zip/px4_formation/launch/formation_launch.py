from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
import os

PX4_PATH = os.path.expanduser('~/PX4-Autopilot')

def generate_launch_description():
    return LaunchDescription([
        ExecuteProcess(
            cmd=[f'{PX4_PATH}/Tools/simulation/gazebo-classic/sitl_multiple_run.sh', '-n', '4'],
            shell=True,
            output='screen'
        ),
        Node(
            package='px4_formation',
            executable='formation_node',
            name='formation_node',
            output='screen',
            parameters=[{
                'connections': [
                    'udp://:14540',
                    'udp://:14541',
                    'udp://:14542',
                    'udp://:14543'
                ],
                'takeoff_alt': 3.0,
                'spacing': 2.0
            }]
        )
    ])
